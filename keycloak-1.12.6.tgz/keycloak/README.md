# Keycloak Helm Chart


## ProblemThis Helm chart deploys Keycloak Operator and optionally a Keycloak instance on Kubernetes.



When installing the Keycloak Helm chart, you encountered the following error:## Prerequisites



```- Kubernetes 1.19+

Error: unable to build kubernetes objects from release manifest: resource mapping not found for name: "keycloak" namespace: "keycloak" from "": no matches for kind "Keycloak" in version "k8s.keycloak.org/v2alpha1"- Helm 3.2.0+

ensure CRDs are installed first

```## Installation



This error occurs because:### Install Operator Only (Recommended)

1. Helm tries to install all resources simultaneously

2. The Keycloak instance (custom resource) requires the CRD to exist firstBy default, this chart only installs the Keycloak Operator:

3. Without proper ordering, the Keycloak CR might be created before the CRD is registered

```bash

## Solutionhelm install keycloak chronolite/keycloak -n keycloak --create-namespace

```

The fix implements **Helm hooks** to ensure proper installation order:

### Install Operator + Keycloak Instance

### Changes Made

To install both the operator and a Keycloak instance:

#### 1. Added Helm Hooks to CRD Files

```bash

Both CRD files now include annotations for Helm hooks:helm install keycloak chronolite/keycloak \

  -n keycloak \

**File**: `charts/keycloak/templates/keycloaks.crd.yaml`  --create-namespace \

**File**: `charts/keycloak/templates/keycloakrealmimports.crd.yaml`  --set keycloak.enabled=true \

  --set keycloak.hostname.hostname=keycloak.example.com

```yaml```

metadata:

  name: "keycloaks.k8s.keycloak.org"## Architecture

  annotations:

    helm.sh/hook: pre-install,pre-upgradeThis chart follows a **two-phase installation** approach:

    helm.sh/hook-weight: "-5"

    helm.sh/hook-delete-policy: before-hook-creation1. **CRDs Installation** (Helm hook `pre-install`, `pre-upgrade` with weight `-5`)

```   - Installs Custom Resource Definitions first

   - `keycloaks.k8s.keycloak.org`

**Annotation Explanation**:   - `keycloakrealmimports.k8s.keycloak.org`

- `helm.sh/hook: pre-install,pre-upgrade`: Installs CRDs **before** the main chart resources

- `helm.sh/hook-weight: "-5"`: Ensures CRDs install first (negative weight = higher priority)2. **Operator + Instance Installation**

- `helm.sh/hook-delete-policy: before-hook-creation`: Allows CRD updates on upgrades   - Installs the Keycloak Operator

   - Optionally installs a Keycloak instance (if `keycloak.enabled=true`)

#### 2. Fixed Chart.yaml Merge Conflict

This ensures CRDs are always available before the operator or instances are deployed.

Resolved the version conflict:

- Version: `1.12.1`## Configuration

- AppVersion: `26.4.0`

### Operator Configuration

#### 3. Added NOTES.txt

| Parameter | Description | Default |

Created a helpful post-installation message that guides users on:|-----------|-------------|---------|

- How to access Keycloak| `operator.enabled` | Enable Keycloak Operator | `true` |

- How to get admin credentials| `operator.namespace` | Namespace for operator | `keycloak-operator` |

- Next steps for deploying Keycloak instances| `operator.image.registry` | Operator image registry | `ghcr.io/chronolite-technologies` |

| `operator.image.repository` | Operator image repository | `mirrors/keycloak/keycloak-operator` |

#### 4. Created Comprehensive README.md| `operator.image.tag` | Operator image tag | `""` (uses `.Chart.AppVersion`) |



Added documentation covering:### Keycloak Instance Configuration

- Installation scenarios

- Configuration options| Parameter | Description | Default |

- Troubleshooting guide|-----------|-------------|---------|

- Architecture explanation| `keycloak.enabled` | Enable Keycloak instance | `false` |

| `keycloak.name` | Keycloak instance name | `keycloak` |

## Installation Order| `keycloak.namespace` | Namespace for instance | `keycloak` |

| `keycloak.replicas` | Number of replicas | `1` |

With the fix, resources are now installed in this order:| `keycloak.image.registry` | Keycloak image registry | `ghcr.io/chronolite-technologies` |

| `keycloak.image.repository` | Keycloak image repository | `mirrors/keycloak/keycloak` |

```| `keycloak.image.tag` | Keycloak image tag | `""` (uses `.Chart.AppVersion`) |

1. Pre-install hooks (weight: -5)

   ├── keycloaks.crd.yaml### Database Configuration

   └── keycloakrealmimports.crd.yaml

   | Parameter | Description | Default |

2. Main chart resources|-----------|-------------|---------|

   ├── operator-kubernetes.yaml (ServiceAccount, RBAC, Deployment)| `keycloak.database.vendor` | Database vendor | `postgres` |

   └── keycloak-instance.yaml (only if keycloak.enabled=true)| `keycloak.database.host` | Database host | `""` |

```| `keycloak.database.port` | Database port | `5432` |

| `keycloak.database.database` | Database name | `keycloak` |

## Testing the Fix| `keycloak.database.credentialsSecret` | Secret with DB credentials | `keycloak-db-secret` |



### Test 1: Clean Installation### Hostname Configuration



```bash| Parameter | Description | Default |

# Ensure namespace exists|-----------|-------------|---------|

kubectl create namespace keycloak| `keycloak.hostname.hostname` | Keycloak hostname | `""` |

| `keycloak.hostname.admin` | Admin console hostname | `""` |

# Install operator only (default)

helm install keycloak ./charts/keycloak -n keycloak### Resource Configuration



# Verify CRDs are installed| Parameter | Description | Default |

kubectl get crd | grep keycloak|-----------|-------------|---------|

```| `keycloak.resources.requests.cpu` | CPU request | `500m` |

| `keycloak.resources.requests.memory` | Memory request | `512Mi` |

Expected output:| `keycloak.resources.limits.cpu` | CPU limit | `1000m` |

```| `keycloak.resources.limits.memory` | Memory limit | `1Gi` |

keycloakrealmimports.k8s.keycloak.org   2024-10-19T...

keycloaks.k8s.keycloak.org              2024-10-19T...## Common Installation Scenarios

```

### Scenario 1: Operator Only (Default)

### Test 2: Install with Keycloak Instance

```bash

```bashhelm install keycloak chronolite/keycloak -n keycloak --create-namespace

helm install keycloak ./charts/keycloak \```

  -n keycloak \

  --set keycloak.enabled=true \Then create Keycloak instances manually using `kubectl apply`.

  --set keycloak.http.enabled=true

```### Scenario 2: Operator + Keycloak with External Database



This should now succeed without the "no matches for kind" error.```bash

# Create database secret first

### Test 3: Upgradekubectl create secret generic keycloak-db-secret \

  --from-literal=username=keycloak \

```bash  --from-literal=password=your-password \

helm upgrade keycloak ./charts/keycloak -n keycloak  -n keycloak

```

# Install with database config

CRDs will be updated via the `pre-upgrade` hook.helm install keycloak chronolite/keycloak \

  -n keycloak \

## Default Configuration  --create-namespace \

  --set keycloak.enabled=true \

By default:  --set keycloak.database.host=postgres.example.com \

- **Operator**: Enabled (`operator.enabled: true`)  --set keycloak.database.vendor=postgres \

- **Keycloak Instance**: Disabled (`keycloak.enabled: false`)  --set keycloak.hostname.hostname=keycloak.example.com

```

This allows you to:

1. Install the operator first### Scenario 3: Operator + Keycloak with HTTP (Development)

2. Create Keycloak instances later (manually or via Helm upgrade)

```bash

## Manual Keycloak Instance Creationhelm install keycloak chronolite/keycloak \

  -n keycloak \

After installing the operator, you can create instances manually:  --create-namespace \

  --set keycloak.enabled=true \

```bash  --set keycloak.http.enabled=true

kubectl apply -f - <<EOF```

apiVersion: k8s.keycloak.org/v2alpha1

kind: Keycloak## Upgrading

metadata:

  name: keycloakTo upgrade the chart:

  namespace: keycloak

spec:```bash

  instances: 1helm upgrade keycloak chronolite/keycloak -n keycloak

  http:```

    httpEnabled: true

EOFThe CRDs will be automatically updated via the `pre-upgrade` hook.

```

## Uninstalling

## Best Practices

```bash

1. **Install operator first**: Use default values to install just the operatorhelm uninstall keycloak -n keycloak

2. **Configure database**: Create database secrets before enabling Keycloak instance```

3. **Use hostname**: Set `keycloak.hostname.hostname` for production deployments

4. **Resource limits**: Adjust resources based on your expected load**Note**: CRDs are not automatically removed. To remove them:



## Additional Notes```bash

kubectl delete crd keycloaks.k8s.keycloak.org

### Why Not Use `crd-install` Hook?kubectl delete crd keycloakrealmimports.k8s.keycloak.org

```

Helm 3 deprecated the `crd-install` hook in favor of the `crds/` directory. However, we use `pre-install`/`pre-upgrade` hooks instead because:

## Troubleshooting

1. **Flexibility**: Allows templating in CRD files if needed

2. **Updates**: CRDs in `crds/` directory are never updated; hooks allow updates### Error: "no matches for kind Keycloak"

3. **Control**: Explicit ordering with hook weights

This error occurs if CRDs are not installed before the Keycloak instance. This chart uses Helm hooks to ensure proper installation order. If you still encounter this:

### Cleanup on Uninstall

1. Verify CRDs are installed:

CRDs are **not** automatically deleted on `helm uninstall` (this is Helm's default behavior to prevent data loss). To remove CRDs:

   ```bash

```bash   kubectl get crd | grep keycloak

kubectl delete crd keycloaks.k8s.keycloak.org   ```

kubectl delete crd keycloakrealmimports.k8s.keycloak.org

```2. If missing, manually install CRDs:



## Files Modified   ```bash

   kubectl apply -f charts/keycloak/templates/keycloaks.crd.yaml

1. `charts/keycloak/Chart.yaml` - Fixed merge conflict   kubectl apply -f charts/keycloak/templates/keycloakrealmimports.crd.yaml

2. `charts/keycloak/templates/keycloaks.crd.yaml` - Added Helm hooks   ```

3. `charts/keycloak/templates/keycloakrealmimports.crd.yaml` - Added Helm hooks

4. `charts/keycloak/templates/NOTES.txt` - Created (new file)3. Then upgrade the release:

5. `charts/keycloak/README.md` - Created (new file)

   ```bash

## Verification   helm upgrade keycloak chronolite/keycloak -n keycloak

   ```

To verify the fix works:

### Operator Not Starting

```bash

# Clean up any previous installationCheck operator logs:

helm uninstall keycloak -n keycloak 2>/dev/null || true

kubectl delete namespace keycloak 2>/dev/null || true```bash

kubectl logs -n keycloak-operator deployment/keycloak-operator

# Wait for namespace deletion```

kubectl wait --for=delete namespace/keycloak --timeout=60s 2>/dev/null || true

### Keycloak Instance Not Ready

# Create namespace

kubectl create namespace keycloakCheck Keycloak instance status:



# Install with the fix```bash

helm install keycloak ./charts/keycloak -n keycloakkubectl get keycloak -n keycloak

kubectl describe keycloak keycloak -n keycloak

# Check installation```

kubectl get crd | grep keycloak

kubectl get deployment -n keycloak-operatorCheck operator logs for errors:

```

```bash

All commands should succeed without the "no matches for kind" error.kubectl logs -n keycloak-operator deployment/keycloak-operator --tail=100

```

## Contributing

Contributions are welcome! Please read the contributing guidelines before submitting pull requests.

## License

This chart is licensed under the Apache License 2.0.

## Links

- [Keycloak](https://www.keycloak.org/)
- [Keycloak Operator Documentation](https://www.keycloak.org/operator/installation)
- [Keycloak on Kubernetes](https://www.keycloak.org/operator/basic-deployment)
